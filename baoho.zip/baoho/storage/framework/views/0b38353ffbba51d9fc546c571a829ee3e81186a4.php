<!DOCTYPE html>
<html>
<head>

    <title>Công ty bảo hộ lao động Đức Sơn| Chuyên cung cấp đồ bảo hộ lao động</title>
    <!--/tags -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="description" content="bảo hộ lao động đức sơn, đồ bảo hộ chất lượng cao, đại lý phân phối chính hãng đồ bảo hộ lao động chất lượng cao, chiết khấu cao lên tới hơn 10% tổng giá trị đơn hàng">
    
    <meta name="keywords" content="Bảo hộ lao động đức sơn, <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($category->name); ?>, <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>"/>
    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta rel="canonical" href="http://baohoducson.com">
    <script type="application/x-javascript"> addEventListener("load", function () {
        setTimeout(hideURLbar, 0);
    }, false);

    function hideURLbar() {
        window.scrollTo(0, 1);
    } </script>
    <!--//tags -->
    <link href="<?php echo e(asset('web/css/bootstrap.css')); ?>" rel="stylesheet" type="text/css" media="all"/>
    <link href="<?php echo e(asset('web/css/style.css')); ?>" rel="stylesheet" type="text/css" media="all"/>
    <link href="<?php echo e(asset('web/css/font-awesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('web/css/easy-responsive-tabs.css')); ?>" rel='stylesheet' type='text/css'/>
    <!-- //for bootstrap working -->
    <link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800" rel="stylesheet">
    <link href='//fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,900,900italic,700italic'
          rel='stylesheet' type='text/css'>
    <script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>
    
     

<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
ga('create', 'UA-121491928-1', 'baohoducson.com');
ga('require', 'displayfeatures');
ga('send', 'pageview');
</script>
</head>
<body>
    <!-- Load Facebook SDK for JavaScript -->
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/vi_VN/sdk/xfbml.customerchat.js#xfbml=1&version=v2.12&autoLogAppEvents=1';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<!-- Your customer chat code -->
<div class="fb-customerchat"
  attribution="setup_tool"
  page_id="177187782943702"
  theme_color="#fa3c4c"
  logged_in_greeting="Chào bạn!"
  logged_out_greeting="Chào bạn!">
</div>

    <?php echo $__env->make('web.detail.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('web.detail.header-bot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('web.detail.model1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('web.detail.model2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('web.detail.banner-top', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('web.detail.banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    
    <div id="app">

    <?php echo $__env->make('web.detail.new', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <?php echo $__env->make('web.detail.grids', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('web.detail.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    
    <?php echo $__env->make('web.detail.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>
    <?php echo $__env->make('web.detail.js', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script src="<?php echo e(asset('web/js/jquery.flexisel.js')); ?>"></script>
  <script>
    $(window).load(function () {
      $("#flexiselDemo1").flexisel({
        visibleItems: 4,
        animationSpeed: 1000,
        autoPlay: true,
        autoPlaySpeed: 3000,
        pauseOnHover: true,
        enableResponsiveBreakpoints: true,
        responsiveBreakpoints: {
          portrait: {
            changePoint: 480,
            visibleItems: 1
          },
          landscape: {
            changePoint: 640,
            visibleItems: 2
          },
          tablet: {
            changePoint: 768,
            visibleItems: 3
          }
        }
      });

    });
  </script>

</body>
</html>