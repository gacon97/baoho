<div class="form-group row">
    <label class="col-sm-2 form-control-label text-xs-right"> <?php echo e($label); ?> </label>
    <div class="col-sm-10">
        <div class="wyswyg">
            <div class="toolbar">
                                <span class="ql-format-group">
                                    <select title="Kích cỡ chữ" class="ql-size">
                                        <option value="10px">Nhỏ</option>
                                        <option value="13px" selected>Thường</option>
                                        <option value="18px">Lớn</option>
                                        <option value="32px">Rất lớn</option>
                                    </select>
                                </span>
                <span class="ql-format-group">
                                    <span title="Đậm" class="ql-format-button ql-bold"></span>
                                    <span class="ql-format-separator"></span>
                                    <span title="Nghiêng" class="ql-format-button ql-italic"></span>
                                    <span class="ql-format-separator"></span>
                                    <span title="Gạch chân" class="ql-format-button ql-underline"></span>
                                    <span class="ql-format-separator"></span>
                                    <span title="Gạch ngang" class="ql-format-button ql-strike"></span>
                                </span>
                <span class="ql-format-group">
                                    <select title="Màu chữ" class="ql-color">
                                        <option value="rgb(0, 0, 0)" label="rgb(0, 0, 0)" selected></option>
                                        <option value="rgb(230, 0, 0)" label="rgb(230, 0, 0)"></option>
                                        <option value="rgb(255, 153, 0)" label="rgb(255, 153, 0)"></option>
                                        <option value="rgb(255, 255, 0)" label="rgb(255, 255, 0)"></option>
                                        <option value="rgb(0, 138, 0)" label="rgb(0, 138, 0)"></option>
                                        <option value="rgb(0, 102, 204)" label="rgb(0, 102, 204)"></option>
                                        <option value="rgb(153, 51, 255)"
                                                label="rgb(153, 51, 255)"></option>
                                        <option value="rgb(255, 255, 255)"
                                                label="rgb(255, 255, 255)"></option>
                                        <option value="rgb(250, 204, 204)"
                                                label="rgb(250, 204, 204)"></option>
                                        <option value="rgb(255, 235, 204)"
                                                label="rgb(255, 235, 204)"></option>
                                        <option value="rgb(255, 255, 204)"
                                                label="rgb(255, 255, 204)"></option>
                                        <option value="rgb(204, 232, 204)"
                                                label="rgb(204, 232, 204)"></option>
                                        <option value="rgb(204, 224, 245)"
                                                label="rgb(204, 224, 245)"></option>
                                        <option value="rgb(235, 214, 255)"
                                                label="rgb(235, 214, 255)"></option>
                                        <option value="rgb(187, 187, 187)"
                                                label="rgb(187, 187, 187)"></option>
                                        <option value="rgb(240, 102, 102)"
                                                label="rgb(240, 102, 102)"></option>
                                        <option value="rgb(255, 194, 102)"
                                                label="rgb(255, 194, 102)"></option>
                                        <option value="rgb(255, 255, 102)"
                                                label="rgb(255, 255, 102)"></option>
                                        <option value="rgb(102, 185, 102)"
                                                label="rgb(102, 185, 102)"></option>
                                        <option value="rgb(102, 163, 224)"
                                                label="rgb(102, 163, 224)"></option>
                                        <option value="rgb(194, 133, 255)"
                                                label="rgb(194, 133, 255)"></option>
                                        <option value="rgb(136, 136, 136)"
                                                label="rgb(136, 136, 136)"></option>
                                        <option value="rgb(161, 0, 0)" label="rgb(161, 0, 0)"></option>
                                        <option value="rgb(178, 107, 0)" label="rgb(178, 107, 0)"></option>
                                        <option value="rgb(178, 178, 0)" label="rgb(178, 178, 0)"></option>
                                        <option value="rgb(0, 97, 0)" label="rgb(0, 97, 0)"></option>
                                        <option value="rgb(0, 71, 178)" label="rgb(0, 71, 178)"></option>
                                        <option value="rgb(107, 36, 178)"
                                                label="rgb(107, 36, 178)"></option>
                                        <option value="rgb(68, 68, 68)" label="rgb(68, 68, 68)"></option>
                                        <option value="rgb(92, 0, 0)" label="rgb(92, 0, 0)"></option>
                                        <option value="rgb(102, 61, 0)" label="rgb(102, 61, 0)"></option>
                                        <option value="rgb(102, 102, 0)" label="rgb(102, 102, 0)"></option>
                                        <option value="rgb(0, 55, 0)" label="rgb(0, 55, 0)"></option>
                                        <option value="rgb(0, 41, 102)" label="rgb(0, 41, 102)"></option>
                                        <option value="rgb(61, 20, 102)" label="rgb(61, 20, 102)"></option>
                                    </select>
                                    <span class="ql-format-separator"></span>
                                    <select title="Màu nền chữ" class="ql-background">
                                        <option value="rgb(0, 0, 0)" label="rgb(0, 0, 0)"></option>
                                        <option value="rgb(230, 0, 0)" label="rgb(230, 0, 0)"></option>
                                        <option value="rgb(255, 153, 0)" label="rgb(255, 153, 0)"></option>
                                        <option value="rgb(255, 255, 0)" label="rgb(255, 255, 0)"></option>
                                        <option value="rgb(0, 138, 0)" label="rgb(0, 138, 0)"></option>
                                        <option value="rgb(0, 102, 204)" label="rgb(0, 102, 204)"></option>
                                        <option value="rgb(153, 51, 255)"
                                                label="rgb(153, 51, 255)"></option>
                                        <option value="rgb(255, 255, 255)" label="rgb(255, 255, 255)"
                                                selected></option>
                                        <option value="rgb(250, 204, 204)"
                                                label="rgb(250, 204, 204)"></option>
                                        <option value="rgb(255, 235, 204)"
                                                label="rgb(255, 235, 204)"></option>
                                        <option value="rgb(255, 255, 204)"
                                                label="rgb(255, 255, 204)"></option>
                                        <option value="rgb(204, 232, 204)"
                                                label="rgb(204, 232, 204)"></option>
                                        <option value="rgb(204, 224, 245)"
                                                label="rgb(204, 224, 245)"></option>
                                        <option value="rgb(235, 214, 255)"
                                                label="rgb(235, 214, 255)"></option>
                                        <option value="rgb(187, 187, 187)"
                                                label="rgb(187, 187, 187)"></option>
                                        <option value="rgb(240, 102, 102)"
                                                label="rgb(240, 102, 102)"></option>
                                        <option value="rgb(255, 194, 102)"
                                                label="rgb(255, 194, 102)"></option>
                                        <option value="rgb(255, 255, 102)"
                                                label="rgb(255, 255, 102)"></option>
                                        <option value="rgb(102, 185, 102)"
                                                label="rgb(102, 185, 102)"></option>
                                        <option value="rgb(102, 163, 224)"
                                                label="rgb(102, 163, 224)"></option>
                                        <option value="rgb(194, 133, 255)"
                                                label="rgb(194, 133, 255)"></option>
                                        <option value="rgb(136, 136, 136)"
                                                label="rgb(136, 136, 136)"></option>
                                        <option value="rgb(161, 0, 0)" label="rgb(161, 0, 0)"></option>
                                        <option value="rgb(178, 107, 0)" label="rgb(178, 107, 0)"></option>
                                        <option value="rgb(178, 178, 0)" label="rgb(178, 178, 0)"></option>
                                        <option value="rgb(0, 97, 0)" label="rgb(0, 97, 0)"></option>
                                        <option value="rgb(0, 71, 178)" label="rgb(0, 71, 178)"></option>
                                        <option value="rgb(107, 36, 178)"
                                                label="rgb(107, 36, 178)"></option>
                                        <option value="rgb(68, 68, 68)" label="rgb(68, 68, 68)"></option>
                                        <option value="rgb(92, 0, 0)" label="rgb(92, 0, 0)"></option>
                                        <option value="rgb(102, 61, 0)" label="rgb(102, 61, 0)"></option>
                                        <option value="rgb(102, 102, 0)" label="rgb(102, 102, 0)"></option>
                                        <option value="rgb(0, 55, 0)" label="rgb(0, 55, 0)"></option>
                                        <option value="rgb(0, 41, 102)" label="rgb(0, 41, 102)"></option>
                                        <option value="rgb(61, 20, 102)" label="rgb(61, 20, 102)"></option>
                                    </select>
                                </span>
                <span class="ql-format-group">
                                    <span title="Danh sách có số" class="ql-format-button ql-list"></span>
                                    <span class="ql-format-separator"></span>
                                    <span title="Danh sách biểu tượng" class="ql-format-button ql-bullet"></span>
                                    <span class="ql-format-separator"></span>
                                    <select title="Canh lề chữ" class="ql-align">
                                        <option value="left" label="Trái" selected></option>
                                        <option value="center" label="Giữa"></option>
                                        <option value="right" label="Phải"></option>
                                        <option value="justify" label="Thẳng"></option>
                                    </select>
                                </span>
                <span class="ql-format-group"> </span>
            </div>
            <div class="editor"><?php echo e(isset($content)?$content:""); ?></div>
        </div>
    </div>
</div>
