<!-- footer -->
<div class="new_arrivals_agile_w3ls_info">
    <div class="footer">
        <div class="footer_agile_inner_info_w3l">
            <div class="col-md-3 col-xs-12 footer-left">
                <h2><a href="/"><span>BHLĐ</span>Đức Sơn </a></h2>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1658.3545476156482!2d105.78634721845307!3d21.07745214145166!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135aacbf3ef62cd%3A0xe599468d1d094ce6!2zNTggUGjhuqFtIFbEg24gxJDhu5NuZywgWHXDom4gxJDhu4luaCwgVOG7qyBMacOqbSwgSMOgIE7hu5lpLCBWaeG7h3QgTmFt!5e0!3m2!1svi!2s!4v1529991054454"
                        width="100%" height="250" frameborder="0" style="border:0" allowfullscreen></iframe>

            </div>
            <div class="col-md-9  col-xs-12 footer-right">
                <div class="sign-grds">
                    <div class="col-md-4 sign-gd">

                    </div>

                    <div class="col-md-5 sign-gd-two">
                        <h4>Thông tin <span>Cửa hàng</span></h4>
                        <div class="w3-address">
                            <div class="w3-address-grid">
                                <div class="w3-address-left">
                                    <i class="fa fa-phone" aria-hidden="true"></i>
                                </div>
                                <div class="w3-address-right">
                                    <h6>Số điện thoại</h6>
                                    <p>0914 661 829</p>
                                    <p>0985 848 776</p>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="w3-address-grid">
                                <div class="w3-address-left">
                                    <i class="fa fa-envelope" aria-hidden="true"></i>
                                </div>
                                <div class="w3-address-right">
                                    <h6>Địa chỉ Email</h6>
                                    <p>Email :<a href="mailto:example@email.com"> baohoducson@gmail.com</a></p>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="w3-address-grid">
                                <div class="w3-address-left">
                                    <i class="fa fa-map-marker" aria-hidden="true"></i>
                                </div>
                                <div class="w3-address-right">
                                    <h6>Địa chỉ</h6>
                                    <p>Số 58, Phạm Văn Đồng, Phường Xuân Đỉnh, Hà Nội

                                    </p>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 sign-gd flickr-post">
                        <h4>Chủ <span>Cửa hàng</span></h4>
                        <ul>
                            <li><a href="/"><img src="{{ asset('web/images/boss.jpg') }}" alt="bao-ho-duc-son"
                                                 class="img-responsive"/></a></li>
                            <li><a href="/"><img src="{{ asset('web/images/nam.jpg') }}" alt="bao-ho-duc-son"
                                                 class="img-responsive"/></a></li>

                        </ul>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
            <div class="clearfix"></div>

            <p class="copy-right">Design By Ngô Quang Nam

            </p>
        </div>
    </div>
</div>
<!-- //footer -->