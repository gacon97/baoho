<!-- header -->
<div class="header" id="home">
    <div class="container">
        <ul>
            <li><a href="#" data-toggle="modal" data-target="#myModal"><i class="fa fa-unlock-alt"
                                                                          aria-hidden="true"></i> Sign In </a></li>
            <li><a href="#" data-toggle="modal" data-target="#myModal2"><i class="fa fa-pencil-square-o"
                                                                           aria-hidden="true"></i> Sign Up </a></li>
            <li><i class="fa fa-phone" aria-hidden="true"></i> Call : 0914 661 829</li>
            <li><i class="fa fa-envelope-o" aria-hidden="true"></i> <a
                        href="mailto:info@example.com">baohoducson@gmail.com</a></li>
        </ul>
    </div>
</div>
<!-- //header -->