<?php
namespace App\Http\Controllers\Admin;


use Illuminate\Http\Request;
use App\Customer;
use App\Product;
use App\Bill;
use App\Category;

class HomeController extends Controller
{
    public function index()
    {
    	$customers = Customer::all()->count();
    	$products = Product::all()->count();
    	$bills = Bill::all();
    	$bill = Bill::all()->count();
    	$categories = Category::all()->count();
        return view('production.index', compact('customers', 'products', 'bills', 'categories', 'bill'));
    }


}
?>